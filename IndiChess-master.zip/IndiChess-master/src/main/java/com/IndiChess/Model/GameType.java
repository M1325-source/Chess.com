package com.IndiChess.Model;

public enum GameType {

    BLITZ,
    RAPID,

}