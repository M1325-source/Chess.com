package com.IndiChess;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IndiChessApplication {

	public static void main(String[] args) {
		SpringApplication.run(IndiChessApplication.class, args);
	}

}
