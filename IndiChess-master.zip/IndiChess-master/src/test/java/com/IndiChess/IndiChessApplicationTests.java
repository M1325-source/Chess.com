package com.IndiChess;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IndiChessApplicationTests {

	@Test
	void contextLoads() {
	}

}
